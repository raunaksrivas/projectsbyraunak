# restaurant-review-website
We made a website for reviewing different restaurants in the city and help the public know what others think about the restaurant and make a wise decision for enjoying their meals later
